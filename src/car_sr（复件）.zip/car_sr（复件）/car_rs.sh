#!/bin/bash

source home/ucar/ucar_ws/devel/setup.bash
sleep 2 &
gnome-terminal -- bash -c "cd home/ucar/ucar_ws/src/car_rs/scripts;rosrun car_rs car_rs_3.py; exec bash" &
sleep 5 &
gnome-terminal -- bash -c "cd home/ucar/ucar_ws/src/car_rs/scripts;rosrun car_rs car_recnum_change.py.py; exec bash" &
sleep 5 &
